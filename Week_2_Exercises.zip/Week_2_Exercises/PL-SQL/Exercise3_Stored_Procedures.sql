-- Scenario 1
CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest
IS 
    BEGIN
        UPDATE ACCOUNTS SET BALANCE = BALANCE + BALANCE * 0.01 WHERE ACCOUNTTYPE LIKE 'Savings';
    END ProcessMonthlyInterest;

BEGIN  
    ProcessMonthlyInterest;
END;



-- Scenario 2
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus(dept IN VARCHAR2, bonus_perc IN NUMBER)
IS
    BEGIN
        UPDATE EMPLOYEES SET SALARY = SALARY + SALARY * (bonus_perc/100) WHERE DEPARTMENT = dept;
    END UpdateEmployeeBonus;

BEGIN
    UpdateEmployeeBonus('IT', 1);
END;



-- Scenario 3
SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE TransferFunds(senderid in CUSTOMERS.CUSTOMERID%TYPE, recieverid in CUSTOMERS.CUSTOMERID%TYPE, trans_amt in NUMBER)
IS
    SENDER_BAL NUMBER;
    BEGIN
        SELECT BALANCE INTO SENDER_BAL FROM ACCOUNTS WHERE CUSTOMERID = senderid;
        IF trans_amt < SENDER_BAL THEN
            UPDATE ACCOUNTS SET BALANCE = BALANCE - trans_amt WHERE CUSTOMERID = senderid;
            UPDATE ACCOUNTS SET BALANCE = BALANCE + trans_amt WHERE CUSTOMERID = recieverid;
        ELSE
            DBMS_OUTPUT.PUT_LINE('INSUFFICIENT BALANCE');
        END IF;
    END TransferFunds;

BEGIN
    TransferFunds(1, 2, 200);
END;
SELECT * FROM CUSTOMERS;
SELECT * FROM ACCOUNTS;