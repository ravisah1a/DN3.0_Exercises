package com.library.repository;

public class BookRepository {
	public void testing() {
		System.out.println("In Book Repository");
	}
}
